"""生成自签名 SSL 证书"""
import os, datetime
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization

cert_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'certs')
os.makedirs(cert_dir, exist_ok=True)

cert_file = os.path.join(cert_dir, 'cert.pem')
key_file = os.path.join(cert_dir, 'key.pem')

if os.path.exists(cert_file) and os.path.exists(key_file):
    print('证书已存在')
else:
    print('生成自签名证书...')
    
    key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "CN"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Task Manager PWA"),
        x509.NameAttribute(NameOID.COMMON_NAME, "task-manager.local"),
    ])
    
    cert = x509.CertificateBuilder().subject_name(
        subject
    ).issuer_name(
        issuer
    ).public_key(
        key.public_key()
    ).serial_number(
        x509.random_serial_number()
    ).not_valid_before(
        datetime.datetime.utcnow()
    ).not_valid_after(
        datetime.datetime.utcnow() + datetime.timedelta(days=3650)
    ).add_extension(
        x509.SubjectAlternativeName([x509.DNSName("task-manager.local")]),
        critical=False,
    ).sign(key, hashes.SHA256(), default_backend())
    
    with open(key_file, "wb") as f:
        f.write(key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption()
        ))
    
    with open(cert_file, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    
    print(f'✓ 证书已生成: {cert_dir}')
    print(f'  cert.pem ({os.path.getsize(cert_file)} bytes)')
    print(f'  key.pem ({os.path.getsize(key_file)} bytes)')
