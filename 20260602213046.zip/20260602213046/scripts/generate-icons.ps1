# Generate PWA PNG icons using .NET
Add-Type -AssemblyName System.Drawing

$outDir = "c:\Users\张艺严\CodeBuddy\20260601202750\icons"
$sizes = @(72, 96, 128, 144, 152, 192, 384, 512)

foreach ($size in $sizes) {
    $bmp = New-Object System.Drawing.Bitmap($size, $size)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'HighQuality'
    $g.InterpolationMode = 'HighQualityBicubic'
    $g.PixelOffsetMode = 'HighQuality'
    
    # Background rounded rect
    $r = [int]($size * 0.18)
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddArc(0, 0, $r*2, $r*2, 180, 90)
    $path.AddArc($size - $r*2, 0, $r*2, $r*2, 270, 90)
    $path.AddArc($size - $r*2, $size - $r*2, $r*2, $r*2, 0, 90)
    $path.AddArc(0, $size - $r*2, $r*2, $r*2, 90, 90)
    $path.CloseFigure()
    
    # Gradient brush
    $gradientBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        (New-Object System.Drawing.Point(0, 0)),
        (New-Object System.Drawing.Point($size, $size)),
        [System.Drawing.Color]::FromArgb(0x66, 0x7e, 0xea),
        [System.Drawing.Color]::FromArgb(0x76, 0x4b, 0xa2)
    )
    $g.FillPath($gradientBrush, $path)
    
    # White card area
    $margin = [int]($size * 0.15)
    $cardW = $size - $margin * 2
    $cardH = [int]($size * 0.42)
    $cardY = [int]($size * 0.32)
    $cr = [int]($size * 0.06)
    
    $cardPath = New-Object System.Drawing.Drawing2D.GraphicsPath
    $cardPath.AddArc($margin, $cardY, $cr*2, $cr*2, 180, 90)
    $cardPath.AddArc($margin + $cardW - $cr*2, $cardY, $cr*2, $cr*2, 270, 90)
    $cardPath.AddArc($margin + $cardW - $cr*2, $cardY + $cardH - $cr*2, $cr*2, $cr*2, 0, 90)
    $cardPath.AddArc($margin, $cardY + $cardH - $cr*2, $cr*2, $cr*2, 90, 90)
    $cardPath.CloseFigure()
    
    $g.FillPath([System.Drawing.Brushes]::White, $cardPath)
    
    # Checkmark
    $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(0x66, 0x7e, 0xea), [int]($size * 0.07))
    $pen.StartCap = 'Round'
    $pen.EndCap = 'Round'
    $pen.LineJoin = 'Round'
    
    $cx = [int]($size * 0.38)
    $cy = [int]($size * 0.53)
    $off = [int]($size * 0.10)
    $off2 = [int]($size * 0.08)
    $off3 = [int]($size * 0.14)
    
    $points = @(
        (New-Object System.Drawing.Point($cx - $off, $cy)),
        (New-Object System.Drawing.Point($cx - [int]($size * 0.02), $cy + $off2)),
        (New-Object System.Drawing.Point($cx + $off3, $cy - $off2))
    )
    $g.DrawLines($pen, $points)
    
    # Text lines
    $brush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(0xcc, 0xcc, 0xcc))
    $lx = [int]($margin + $cardW * 0.3)
    $lineY1 = [int]($cardY + $cardH * 0.30)
    $lineY2 = [int]($cardY + $cardH * 0.53)
    $lineY3 = [int]($cardY + $cardH * 0.76)
    $lh = [int]($size * 0.025)
    $g.FillRectangle($brush, $lx, $lineY1, [int]($cardW * 0.35), $lh)
    $g.FillRectangle($brush, $lx, $lineY2, [int]($cardW * 0.45), $lh)
    $g.FillRectangle($brush, $lx, $lineY3, [int]($cardW * 0.25), $lh)
    
    $g.Dispose()
    $outPath = Join-Path $outDir "icon-${size}x${size}.png"
    $bmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Host "Generated: icon-${size}x${size}.png"
}

Write-Host "All icons generated successfully!"
