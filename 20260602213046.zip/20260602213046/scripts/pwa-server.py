# -*- coding: utf-8 -*-
"""
工作任务管理器 - PWA 手机安装服务器
启动后，手机和电脑连同一 WiFi，手机浏览器访问即可安装到桌面
"""

import http.server
import ssl
import os
import sys
import socket
import datetime
import io

PORT = 8443
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
CERT_FILE = os.path.join(HERE, 'certs', 'cert.pem')
KEY_FILE = os.path.join(HERE, 'certs', 'key.pem')

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def create_handler():
    class Handler(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=ROOT, **kwargs)
        
        def end_headers(self):
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Service-Worker-Allowed', '/')
            self.send_header('Cache-Control', 'no-cache')
            super().end_headers()
    
    return Handler

def main():
    os.chdir(ROOT)
    
    # Fix Windows console encoding
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    
    local_ip = get_local_ip()
    
    if not os.path.exists(CERT_FILE) or not os.path.exists(KEY_FILE):
        print("[!] SSL certificate not found!")
        print("    Run: python scripts/gen_cert.py")
        return 1
    
    url = f"https://{local_ip}:{PORT}"
    
    print()
    print("=" * 50)
    print("  工作任务管理器 - PWA 手机安装服务器")
    print("=" * 50)
    print()
    print(f"  [OK] HTTPS 服务器已启动")
    print()
    print(f"  手机浏览器打开以下地址：")
    print(f"  {url}")
    print()
    print(f"  首次访问提示「不安全」：")
    print(f"  点击「高级」->「继续前往」即可")
    print(f"  安装后永久离线可用！")
    print()
    print(f"  按 Ctrl+C 停止服务器")
    print("=" * 50)
    print()
    
    handler = create_handler()
    httpd = http.server.HTTPServer(('0.0.0.0', PORT), handler)
    
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(CERT_FILE, KEY_FILE)
    httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n服务器已停止。")
        httpd.server_close()

if __name__ == '__main__':
    main()
