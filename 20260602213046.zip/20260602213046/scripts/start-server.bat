@echo off
chcp 65001 >nul
cd /d "%~dp0.."

echo.
echo ================================================
echo   工作任务管理器 - PWA 手机安装服务器
echo ================================================
echo.

REM 获取本机 IP
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do (
    set IP=%%a
    goto :found_ip
)
:found_ip
set IP=%IP: =%

echo   正在启动 HTTPS 服务器...
echo.
echo   手机浏览器打开以下地址：
echo   https://%IP%:8443
echo.
echo   首次访问提示「不安全」：
echo   点击「高级」-^>「继续前往」即可
echo   安装后永久离线可用！
echo.
echo   按 Ctrl+C 停止服务器
echo ================================================
echo.

C:\Users\张艺严\.workbuddy\binaries\python\versions\3.14.3\python.exe scripts\pwa-server.py
pause
