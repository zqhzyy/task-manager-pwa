Add-Type -AssemblyName System.Drawing

$outDir = "c:\Users\张艺严\CodeBuddy\20260601202750\icons"
$sizes = @(72, 96, 128, 144, 152, 192, 384, 512)

foreach ($size in $sizes) {
    $bmp = New-Object System.Drawing.Bitmap($size, $size)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'HighQuality'

    $bgColor = [System.Drawing.Color]::FromArgb(102, 126, 234)
    $purpleColor = [System.Drawing.Color]::FromArgb(118, 75, 162)
    $whiteColor = [System.Drawing.Color]::White
    $checkColor = [System.Drawing.Color]::FromArgb(102, 126, 234)
    $grayColor = [System.Drawing.Color]::FromArgb(200, 200, 200)

    $r = [int]($size * 0.18)

    # Fill background gradient (simple: just fill with primary color)
    $bgBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        (New-Object System.Drawing.PointF(0, 0)),
        (New-Object System.Drawing.PointF($size, $size)),
        $bgColor, $purpleColor
    )
    $g.FillRectangle($bgBrush, 0, 0, $size, $size)
    $bgBrush.Dispose()

    # White card
    $margin = [int]($size * 0.15)
    $cardW = $size - $margin * 2
    $cardH = [int]($size * 0.42)
    $cardY = [int]($size * 0.32)

    $whiteBrush = New-Object System.Drawing.SolidBrush($whiteColor)
    $g.FillRectangle($whiteBrush, $margin, $cardY, $cardW, $cardH)

    # Checkmark - draw a V shape using lines
    $penColor = $checkColor
    $penW = [Math]::Max(2, [int]($size * 0.06))
    $pen = New-Object System.Drawing.Pen($penColor, $penW)
    $pen.StartCap = 'Round'
    $pen.EndCap = 'Round'

    $cx = [int]($size * 0.38)
    $cy = [int]($size * 0.53)
    $len1 = [int]($size * 0.08)
    $len2 = [int]($size * 0.14)

    $g.DrawLine($pen, $cx - $len1, $cy, $cx, $cy + $len1)
    $g.DrawLine($pen, $cx, $cy + $len1, $cx + $len2, $cy - $len1)
    $pen.Dispose()

    # Text lines
    $grayBrush = New-Object System.Drawing.SolidBrush($grayColor)
    $lx = [int]($margin + $cardW * 0.3)
    $lh = [Math]::Max(1, [int]($size * 0.025))

    $lineY1 = [int]($cardY + $cardH * 0.30)
    $lineY2 = [int]($cardY + $cardH * 0.53)
    $lineY3 = [int]($cardY + $cardH * 0.76)

    $g.FillRectangle($grayBrush, $lx, $lineY1, [int]($cardW * 0.35), $lh)
    $g.FillRectangle($grayBrush, $lx, $lineY2, [int]($cardW * 0.45), $lh)
    $g.FillRectangle($grayBrush, $lx, $lineY3, [int]($cardW * 0.25), $lh)

    $grayBrush.Dispose()
    $whiteBrush.Dispose()
    $g.Dispose()

    $outPath = Join-Path $outDir "icon-${size}x${size}.png"
    $bmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Host "OK: icon-${size}x${size}.png"
}

Write-Host "Done!"
