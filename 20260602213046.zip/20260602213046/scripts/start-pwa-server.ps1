# PWA 手机安装服务器 - 启动脚本
# 功能：启动 HTTPS 本地服务器，手机扫码/输入地址即可安装 PWA

param(
    [int]$Port = 8443
)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectDir = Split-Path -Parent $ScriptDir
$CertDir = "$ScriptDir\certs"

Write-Host ""
Write-Host "╔══════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║   工作任务管理器 - PWA 手机安装工具   ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# 1. 生成自签名证书（如不存在）
if (-not (Test-Path "$CertDir\cert.pem")) {
    Write-Host "[1/3] 生成 SSL 证书..." -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $CertDir -Force | Out-Null

    $openssl = Get-Command openssl -ErrorAction SilentlyContinue
    if ($openssl) {
        & openssl req -x509 -newkey rsa:2048 -keyout "$CertDir\key.pem" -out "$CertDir\cert.pem" -days 365 -nodes -subj "/CN=任务管理器PWA"
    } else {
        # 用 PowerShell 生成自签名证书（Windows 方式）
        $cert = New-SelfSignedCertificate -DnsName "task-manager-pwa.local" -CertStoreLocation "Cert:\CurrentUser\My" -KeyExportPolicy Exportable -NotAfter (Get-Date).AddYears(1)
        $certPath = "$CertDir\task-manager-pwa.pfx"
        $pwd = ConvertTo-SecureString -String "task123" -Force -AsPlainText
        Export-PfxCertificate -Cert $cert -FilePath $certPath -Password $pwd | Out-Null
        
        # 转换为 PEM 格式
        $certBytes = $cert.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert)
        [System.IO.File]::WriteAllBytes("$CertDir\cert.pem", $certBytes)
        
        # 导出私钥为 PEM
        $keyBytes = $cert.PrivateKey.ExportPkcs8PrivateKey()
        [System.IO.File]::WriteAllBytes("$CertDir\key.pem", $keyBytes)
    }
    Write-Host "  ✓ 证书生成完成" -ForegroundColor Green
} else {
    Write-Host "[1/3] 使用已有证书" -ForegroundColor Green
}

# 2. 获取本机 IP
Write-Host "[2/3] 检测网络地址..." -ForegroundColor Yellow
$ipAddresses = @()
Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -ne "127.0.0.1" -and $_.PrefixOrigin -ne "WellKnown" } | ForEach-Object {
    $ipAddresses += $_.IPAddress
}

if ($ipAddresses.Count -eq 0) {
    $ipAddresses = @("127.0.0.1")
    Write-Host "  ⚠ 未检测到局域网 IP，将使用本地地址" -ForegroundColor Red
}

# 3. 启动 Python HTTPS 服务器
Write-Host "[3/3] 启动 HTTPS 服务器..." -ForegroundColor Yellow

# 创建 Python 服务器脚本
$pythonServer = @"
import http.server
import ssl
import socket
import os
import sys

os.chdir(r'$ProjectDir')

class MyHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Service-Worker-Allowed', '/')
        super().end_headers()

port = $Port
server_address = ('0.0.0.0', port)
httpd = http.server.HTTPServer(server_address, MyHandler)

# SSL
context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
context.load_cert_chain(r'$CertDir\cert.pem', r'$CertDir\key.pem')
httpd.socket = context.wrap_socket(httpd.socket, server_side=True)

print(f'HTTPS Server running on port {port}')
httpd.serve_forever()
"@

$pyFile = "$ScriptDir\pwa-server.py"
$pythonServer | Out-File -FilePath $pyFile -Encoding UTF8

Write-Host ""
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor White
Write-Host "  ✅ 服务器已启动！" -ForegroundColor Green
Write-Host ""
Write-Host "  📱 在手机上打开以下任一地址：" -ForegroundColor Yellow
foreach ($ip in $ipAddresses) {
    Write-Host "     https://${ip}:${Port}" -ForegroundColor Cyan
}
Write-Host ""
Write-Host "  ⚠  手机首次访问时会提示「不安全」" -ForegroundColor Red
Write-Host "     请点击「高级」→「继续访问」" -ForegroundColor Red
Write-Host ""
Write-Host "  📲 打开后点击底部「安装」按钮即可" -ForegroundColor Green
Write-Host "     添加到手机桌面，离线也能用！" -ForegroundColor Green
Write-Host ""
Write-Host "  ⏹  按 Ctrl+C 停止服务器" -ForegroundColor Gray
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor White
Write-Host ""

# 启动 Python HTTPS 服务器
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    $python = Get-Command python3 -ErrorAction SilentlyContinue
}
if (-not $python) {
    # 尝试找已安装的 Python
    $pythonPath = "C:\Users\张艺严\.workbuddy\binaries\python\versions\3.14.3\python.exe"
    if (Test-Path $pythonPath) {
        $python = $pythonPath
    } else {
        Write-Host "❌ 未找到 Python，请安装 Python 3" -ForegroundColor Red
        pause
        exit 1
    }
}

if ($python -is [string]) {
    & $python $pyFile
} else {
    & $python.Source $pyFile
}
