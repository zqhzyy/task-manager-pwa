// 使用 Canvas API 生成 PWA 应用图标
// 在浏览器中打开 generate-icons.html 即可下载图标
// 或者使用 Node.js + canvas 模块

const fs = require('fs');
const path = require('path');

// 如果没有 canvas 模块，使用纯 SVG 方案
const sizes = [72, 96, 128, 144, 152, 192, 384, 512];
const iconsDir = path.join(__dirname, '..', 'icons');

if (!fs.existsSync(iconsDir)) {
  fs.mkdirSync(iconsDir, { recursive: true });
}

// 为每个尺寸生成 SVG 图标
sizes.forEach(size => {
  const svgContent = generateIconSVG(size);
  const svgPath = path.join(iconsDir, `icon-${size}x${size}.svg`);
  fs.writeFileSync(svgPath, svgContent);
  console.log(`✅ 生成: icon-${size}x${size}.svg`);
});

console.log('\n📝 SVG 图标已生成！');
console.log('💡 如需 PNG 格式，请在浏览器打开 generate-icons.html 下载');
console.log('   或者使用在线工具转换: https://svgtopng.com/');

function generateIconSVG(size) {
  const margin = size * 0.1;
  const w = size - margin * 2;
  const h = size - margin * 2;
  const r = size * 0.15;
  const cx = size / 2;
  const cy = size / 2;
  const scale = size / 512;

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#667eea"/>
      <stop offset="100%" style="stop-color:#764ba2"/>
    </linearGradient>
  </defs>
  <!-- 圆角背景 -->
  <rect x="${margin}" y="${margin}" width="${w}" height="${h}" rx="${r}" ry="${r}" fill="url(#bg)"/>
  <!-- 剪贴板主体 -->
  <rect x="${cx - scale*100}" y="${cy - scale*110 + scale*20}" width="${scale*200}" height="${scale*260}" rx="${scale*16}" fill="rgba(255,255,255,0.95)"/>
  <!-- 剪贴板顶部 -->
  <path d="M${cx - scale*60},${cy - scale*130 + scale*25} Q${cx - scale*60},${cy - scale*155 + scale*25} ${cx - scale*42},${cy - scale*155 + scale*25} L${cx + scale*42},${cy - scale*155 + scale*25} Q${cx + scale*60},${cy - scale*155 + scale*25} ${cx + scale*60},${cy - scale*130 + scale*25} Z" fill="#667eea"/>
  <!-- 任务行 -->
  <line x1="${cx - scale*70}" y1="${cy - scale*80 + scale*20}" x2="${cx + scale*70}" y2="${cy - scale*80 + scale*20}" stroke="#667eea" stroke-width="${scale*8}" stroke-linecap="round"/>
  <line x1="${cx - scale*70}" y1="${cy - scale*30 + scale*20}" x2="${cx + scale*40}" y2="${cy - scale*30 + scale*20}" stroke="#667eea" stroke-width="${scale*8}" stroke-linecap="round"/>
  <line x1="${cx - scale*70}" y1="${cy + scale*20 + scale*20}" x2="${cx + scale*20}" y2="${cy + scale*20 + scale*20}" stroke="#667eea" stroke-width="${scale*8}" stroke-linecap="round"/>
  <!-- 对勾圆 -->
  <circle cx="${cx - scale*70}" cy="${cy - scale*80 + scale*20}" r="${scale*22}" fill="#27ae60"/>
  <!-- 对勾 -->
  <polyline points="${cx - scale*70 - scale*8},${cy - scale*80 + scale*20} ${cx - scale*70 - scale*2},${cy - scale*80 + scale*20 + scale*6} ${cx - scale*70 + scale*10},${cy - scale*80 + scale*20 - scale*8}" stroke="#fff" stroke-width="${scale*4}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;
}
