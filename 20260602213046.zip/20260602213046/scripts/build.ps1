<#
.SYNOPSIS
工作任务管理器 - 一键打包脚本
生成可分发的安装包和便携版
#>

param(
    [switch]$Portable,    # 仅生成便携版
    [switch]$Installer,  # 仅生成安装版
    [switch]$Zip         # 仅打包成 ZIP
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   工作任务管理器 - 打包脚本 v1.1" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 检查 Node.js
$nodeVersion = $null
try { $nodeVersion = node --version 2>$null } catch {}
if (-not $nodeVersion) {
    Write-Host "[警告] 未检测到 Node.js 环境" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "要生成完整的 Windows 安装包 (.exe)，需要 Node.js 环境。" -ForegroundColor White
    Write-Host "请先安装 Node.js: https://nodejs.org/ (推荐 LTS 版本)" -ForegroundColor White
    Write-Host ""
    Write-Host "或者，我可以为你生成以下无依赖的分发包：" -ForegroundColor White
    Write-Host "  1. ZIP 便携包（解压即用）" -ForegroundColor Green
    Write-Host "  2. HTML 单文件版（浏览器打开即用）" -ForegroundColor Green
    Write-Host ""
    Write-Host "正在生成无依赖分发包..." -ForegroundColor Cyan
    Write-Host ""
    
    # 创建输出目录
    $releaseDir = Join-Path $ScriptDir "release"
    if (Test-Path $releaseDir) { Remove-Item $releaseDir -Recurse -Force }
    New-Item -ItemType Directory -Path $releaseDir -Force | Out-Null
    
    # 生成 HTML 单文件独立版
    Write-Host "[1/2] 生成独立 HTML 文件..." -ForegroundColor Cyan
    Copy-Item (Join-Path $ScriptDir "index.html") (Join-Path $releaseDir "工作任务管理器.html") -Force
    Write-Host "  ✅ 工作任务管理器.html (双击浏览器打开即可使用)" -ForegroundColor Green
    
    # 创建 ZIP 便携包
    Write-Host "[2/2] 创建 ZIP 便携包..." -ForegroundColor Cyan
    
    # 创建临时打包目录
    $packDir = Join-Path $releaseDir "工作任务管理器_v1.1"
    New-Item -ItemType Directory -Path $packDir -Force | Out-Null
    
    # 复制必要文件
    Copy-Item (Join-Path $ScriptDir "index.html") $packDir -Force
    Copy-Item (Join-Path $ScriptDir "manifest.json") $packDir -Force
    Copy-Item (Join-Path $ScriptDir "sw.js") $packDir -Force
    Copy-Item (Join-Path $ScriptDir "README.md") $packDir -Force -ErrorAction SilentlyContinue
    
    # 复制 icons 目录
    $iconsDir = Join-Path $ScriptDir "icons"
    if (Test-Path $iconsDir) {
        $destIcons = Join-Path $packDir "icons"
        New-Item -ItemType Directory -Path $destIcons -Force | Out-Null
        Copy-Item (Join-Path $iconsDir "*") $destIcons -Recurse -Force
    }
    
    # 创建使用说明
    @"
工作任务管理器 v1.1
===================

📋 功能特性：
  - 三类任务：关注跟踪事项、临时任务、计划工作
  - 优先级划分：高🔴 / 中🟡 / 低🟢
  - 五级进度：启动 → 1/4 → 1/2 → 3/4 → 全部完成
  - 责任部门/责任人：关注跟踪事项支持指定责任部门与责任人
  - 文件导入：支持 TXT / MD / CSV 文件导入
  - 数据本地存储：所有数据保存在浏览器中

🚀 使用方式：
  方式一：直接双击 index.html 用浏览器打开
  方式二：部署到 Web 服务器，支持 PWA 安装到桌面
  方式三：安装 Node.js 后运行 npm install && npm run dist:win:installer 生成 .exe 安装包

📁 文件说明：
  - index.html     主程序（纯离线可用）
  - manifest.json   PWA 配置文件
  - sw.js          Service Worker（离线缓存）
  - icons/         应用图标

💡 提示：
  - 推荐使用 Chrome / Edge 浏览器打开
  - 数据存储在浏览器 localStorage 中，请勿清理浏览器数据
  - 可通过「导出数据」功能备份任务数据
"@ | Out-File -FilePath (Join-Path $packDir "使用说明.txt") -Encoding UTF8
    
    # 打包 ZIP
    $zipPath = Join-Path $releaseDir "工作任务管理器_v1.1_便携包.zip"
    if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
    
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::CreateFromDirectory($packDir, $zipPath)
    
    # 清理临时目录
    Remove-Item $packDir -Recurse -Force
    
    Write-Host "  ✅ 工作任务管理器_v1.1_便携包.zip" -ForegroundColor Green
    
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "  打包完成！" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "📦 输出文件位于: $releaseDir" -ForegroundColor White
    Write-Host ""
    Get-ChildItem $releaseDir | ForEach-Object {
        $size = if ($_.Length -gt 1MB) { "{0:N2} MB" -f ($_.Length/1MB) } else { "{0:N1} KB" -f ($_.Length/1KB) }
        Write-Host "  📄 $($_.Name) ($size)" -ForegroundColor Yellow
    }
    Write-Host ""
    Write-Host "💡 分享方式：" -ForegroundColor White
    Write-Host "  1. 将 ZIP 文件发送给他人，解压后双击 index.html 即可使用" -ForegroundColor White
    Write-Host "  2. 将 HTML 文件直接发送给他人，双击打开即可使用" -ForegroundColor White
    Write-Host ""
    Write-Host "⚠️  如需生成 .exe 安装包，请安装 Node.js 后重新运行此脚本" -ForegroundColor Yellow
    Write-Host ""

    # 打开输出目录
    Start-Process $releaseDir
    exit 0
}

Write-Host "✅ Node.js $nodeVersion 已就绪" -ForegroundColor Green
Write-Host ""

# 检查 PNG 图标
$png512 = Join-Path $ScriptDir "icons\icon-512x512.png"
if (-not (Test-Path $png512)) {
    Write-Host "[警告] 未找到 icons/icon-512x512.png" -ForegroundColor Yellow
    Write-Host "请先运行 generate-png-icons.html 生成 PNG 图标" -ForegroundColor Yellow
    Write-Host "在浏览器中打开: scripts/generate-png-icons.html" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "继续打包（可能使用 SVG 图标替代）..." -ForegroundColor Yellow
}

# 安装依赖
Write-Host "[1/3] 安装 npm 依赖..." -ForegroundColor Cyan
npm install --no-audit --no-fund 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ npm install 失败" -ForegroundColor Red
    exit 1
}
Write-Host "  ✅ 依赖安装完成" -ForegroundColor Green

# 打包
Write-Host "[2/3] 开始打包..." -ForegroundColor Cyan

if ($Portable) {
    Write-Host "  生成便携版 (.exe)..." -ForegroundColor White
    npx electron-builder --win portable --x64
} elseif ($Installer) {
    Write-Host "  生成安装版 (NSIS .exe)..." -ForegroundColor White
    npx electron-builder --win nsis --x64
} else {
    Write-Host "  生成安装版 + 便携版..." -ForegroundColor White
    npx electron-builder --win nsis portable --x64
}

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ 打包失败" -ForegroundColor Red
    exit 1
}

# 打开输出目录
$releaseDir = Join-Path $ScriptDir "release"
Write-Host ""
Write-Host "[3/3] 打包完成！" -ForegroundColor Green
Write-Host ""
Write-Host "📦 输出文件位于: $releaseDir" -ForegroundColor White
Write-Host ""
Get-ChildItem $releaseDir -Filter "*.exe" | ForEach-Object {
    $size = "{0:N2} MB" -f ($_.Length/1MB)
    Write-Host "  📄 $($_.Name) ($size)" -ForegroundColor Yellow
}
Write-Host ""
Write-Host "💡 将 .exe 文件发送给他人即可安装使用" -ForegroundColor White

Start-Process $releaseDir
