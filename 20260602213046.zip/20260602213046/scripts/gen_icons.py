# -*- coding: utf-8 -*-
import struct, zlib, os

out_dir = r"c:\Users\张艺严\CodeBuddy\20260601202750\icons"
sizes = [72, 96, 128, 144, 152, 192, 384, 512]

def make_png(w, h, px):
    def ch(ct, d):
        c = ct + d
        return struct.pack('>I', len(d)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)
    raw = b''
    for y in range(h):
        raw += b'\x00'
        for x in range(w):
            i = (y * w + x) * 4
            raw += bytes([px[i], px[i+1], px[i+2], px[i+3]])
    return b'\x89PNG\r\n\x1a\n' + ch(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) + ch(b'IDAT', zlib.compress(raw)) + ch(b'IEND', b'')

def lerp(a, b, t):
    return int(a + (b - a) * t)

for size in sizes:
    w = h = size
    px = bytearray(w * h * 4)

    # Gradient background
    for y in range(h):
        t = y / (h - 1) if h > 1 else 0
        r = lerp(102, 118, t)
        g = lerp(126, 75, t)
        b = lerp(234, 162, t)
        for x in range(w):
            i = (y * w + x) * 4
            px[i] = r
            px[i+1] = g
            px[i+2] = b
            px[i+3] = 255

    # White card
    m = int(w * 0.15)
    cw = w - m * 2
    ch = int(h * 0.42)
    cy = int(h * 0.32)
    for y in range(cy, cy + ch):
        for x in range(m, m + cw):
            i = (y * w + x) * 4
            px[i] = px[i+1] = px[i+2] = 255
            px[i+3] = 255

    # Checkmark
    cx = int(w * 0.38)
    cy2 = int(h * 0.53)
    pw = max(2, int(w * 0.06))
    half = pw // 2
    l1 = int(w * 0.08)
    l2 = int(w * 0.14)

    def thick_line(x1, y1, x2, y2):
        dx = abs(x2 - x1)
        dy = abs(y2 - y1)
        steps = max(dx, dy, 1)
        for s in range(steps + 1):
            t = s / steps
            px2 = int(x1 + (x2 - x1) * t)
            py2 = int(y1 + (y2 - y1) * t)
            for dy2 in range(-half, half + 1):
                for dx2 in range(-half, half + 1):
                    nx, ny = px2 + dx2, py2 + dy2
                    if 0 <= nx < w and 0 <= ny < h:
                        i2 = (ny * w + nx) * 4
                        px[i2] = 102
                        px[i2+1] = 126
                        px[i2+2] = 234
                        px[i2+3] = 255

    thick_line(cx - l1, cy2, cx, cy2 + l1)
    thick_line(cx, cy2 + l1, cx + l2, cy2 - l1)

    # Gray text lines
    lx = int(m + cw * 0.3)
    lh = max(1, int(w * 0.025))
    for ly in [int(cy + ch * 0.30), int(cy + ch * 0.53), int(cy + ch * 0.76)]:
        for y in range(ly, ly + lh):
            for x in range(lx, lx + int(cw * (0.45 if ly == int(cy + ch * 0.53) else 0.35 if ly == int(cy + ch * 0.30) else 0.25))):
                if 0 <= y < h and 0 <= x < w:
                    i = (y * w + x) * 4
                    px[i] = px[i+1] = px[i+2] = 200
                    px[i+3] = 255

    # Save
    png = make_png(w, h, px)
    fname = os.path.join(out_dir, f"icon-{size}x{size}.png")
    with open(fname, 'wb') as f:
        f.write(png)
    print(f"OK: icon-{size}x{size}.png ({len(png)} bytes)")

print("Done!")
