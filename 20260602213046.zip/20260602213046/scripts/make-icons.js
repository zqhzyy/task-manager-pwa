// 直接生成 SVG 图标到 icons 目录
const fs = require('fs');
const path = require('path');

const sizes = [72, 96, 128, 144, 152, 192, 384, 512];
const iconsDir = path.join(__dirname, '..', 'icons');

if (!fs.existsSync(iconsDir)) fs.mkdirSync(iconsDir, { recursive: true });

sizes.forEach(size => {
  const svg = iconSVG(size);
  fs.writeFileSync(path.join(iconsDir, `icon-${size}x${size}.svg`), svg);
  console.log(`✅ icon-${size}x${size}.svg`);
});

console.log('\n完成！共生成 ' + sizes.length + ' 个图标');

function iconSVG(s) {
  const m = s * 0.08;
  const w = s - m * 2;
  const h = s - m * 2;
  const r = s * 0.16;
  const cx = s / 2;
  const cy = s / 2;
  const sc = s / 512;

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${s}" height="${s}" viewBox="0 0 ${s} ${s}">
  <defs>
    <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#667eea"/>
      <stop offset="100%" style="stop-color:#764ba2"/>
    </linearGradient>
  </defs>
  <rect x="${m}" y="${m}" width="${w}" height="${h}" rx="${r}" fill="url(#g)"/>
  <rect x="${cx-sc*100}" y="${cy-sc*90}" width="${sc*200}" height="${sc*260}" rx="${sc*16}" fill="rgba(255,255,255,0.95)"/>
  <path d="M${cx-sc*60},${cy-sc*115} Q${cx-sc*60},${cy-sc*140} ${cx-sc*42},${cy-sc*140} L${cx+sc*42},${cy-sc*140} Q${cx+sc*60},${cy-sc*140} ${cx+sc*60},${cy-sc*115} Z" fill="#667eea"/>
  <line x1="${cx-sc*70}" y1="${cy-sc*60}" x2="${cx+sc*70}" y2="${cy-sc*60}" stroke="#667eea" stroke-width="${sc*8}" stroke-linecap="round"/>
  <line x1="${cx-sc*70}" y1="${cy-sc*10}" x2="${cx+sc*40}" y2="${cy-sc*10}" stroke="#667eea" stroke-width="${sc*8}" stroke-linecap="round"/>
  <line x1="${cx-sc*70}" y1="${cy+sc*40}" x2="${cx+sc*20}" y2="${cy+sc*40}" stroke="#667eea" stroke-width="${sc*8}" stroke-linecap="round"/>
  <circle cx="${cx-sc*70}" cy="${cy-sc*60}" r="${sc*22}" fill="#27ae60"/>
  <polyline points="${cx-sc*78},${cy-sc*60} ${cx-sc*72},${cy-sc*54} ${cx-sc*60},${cy-sc*68}" stroke="#fff" stroke-width="${sc*4}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`;
}
