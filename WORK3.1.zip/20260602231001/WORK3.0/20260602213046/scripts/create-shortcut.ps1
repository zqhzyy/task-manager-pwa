<#
.SYNOPSIS
工作任务管理器 - Windows 桌面快捷方式创建工具
生成：开始菜单快捷方式 / 桌面快捷方式 / 任务栏固定引导
#>

param(
    [switch]$Uninstall  # 卸载快捷方式
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectDir = Split-Path -Parent $ScriptDir

$AppName = "工作任务管理器"
$HtmlPath = Join-Path $ProjectDir "index.html"
$IconPath = Join-Path $ProjectDir "icons\icon-192x192.png"

if (-not (Test-Path $HtmlPath)) {
    Write-Host "❌ 未找到 index.html，请确保在项目目录中运行此脚本" -ForegroundColor Red
    exit 1
}

if ($Uninstall) {
    Write-Host ""
    Write-Host "🗑️  正在移除快捷方式..." -ForegroundColor Cyan
    
    # 移除桌面快捷方式
    $desktopShortcut = [Environment]::GetFolderPath("Desktop") + "\$AppName.url"
    if (Test-Path $desktopShortcut) {
        Remove-Item $desktopShortcut -Force
        Write-Host "  ✅ 已移除桌面快捷方式" -ForegroundColor Green
    }
    
    # 移除开始菜单快捷方式
    $startMenuShortcut = [Environment]::GetFolderPath("StartMenu") + "\$AppName.url"
    if (Test-Path $startMenuShortcut) {
        Remove-Item $startMenuShortcut -Force
        Write-Host "  ✅ 已移除开始菜单快捷方式" -ForegroundColor Green
    }
    
    Write-Host ""
    Write-Host "快捷方式已全部移除" -ForegroundColor Green
    exit 0
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   工作任务管理器 - 桌面快捷方式工具" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 创建 .url 快捷方式内容
$iconLine = ""
if (Test-Path $IconPath) {
    $iconLine = "IconFile=$IconPath`r`nIconIndex=0`r`n"
}

$urlContent = @"
[InternetShortcut]
URL=file:///$($HtmlPath.Replace('\', '/'))
$iconLine
"@

# 1. 桌面快捷方式
Write-Host "[1/2] 创建桌面快捷方式..." -ForegroundColor Cyan
$desktopPath = [Environment]::GetFolderPath("Desktop") + "\$AppName.url"
$urlContent | Out-File -FilePath $desktopPath -Encoding ASCII
Write-Host "  ✅ 桌面快捷方式已创建" -ForegroundColor Green

# 2. 开始菜单快捷方式
Write-Host "[2/2] 创建开始菜单快捷方式..." -ForegroundColor Cyan
$startMenuPath = [Environment]::GetFolderPath("StartMenu") + "\$AppName.url"
$urlContent | Out-File -FilePath $startMenuPath -Encoding ASCII
Write-Host "  ✅ 开始菜单快捷方式已创建" -ForegroundColor Green

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  🎉 快捷方式创建完成！" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "📌 现在可以：" -ForegroundColor White
Write-Host "  1. 在桌面双击「$AppName」打开应用" -ForegroundColor White
Write-Host "  2. 在开始菜单搜索「$AppName」打开应用" -ForegroundColor White
Write-Host "  3. 右键桌面快捷方式 → 固定到任务栏" -ForegroundColor White
Write-Host ""
Write-Host "💡 提示：" -ForegroundColor White
Write-Host "  - 推荐用 Chrome/Edge 浏览器打开，体验最佳" -ForegroundColor White
Write-Host "  - 打开后可点击左侧「💻 安装到电脑」获得完整 PWA 体验" -ForegroundColor White
Write-Host "  - 运行 .\create-shortcut.ps1 -Uninstall 可移除快捷方式" -ForegroundColor White
Write-Host ""

# 询问是否设置默认浏览器
Write-Host "⚙️  是否将 Chrome 设为打开此应用的默认浏览器？" -ForegroundColor Yellow
Write-Host "   (这会让应用以独立窗口模式打开，体验更好)" -ForegroundColor Yellow
Write-Host "   1. 是（推荐）" -ForegroundColor White
Write-Host "   2. 否（使用系统默认浏览器）" -ForegroundColor White
$choice = Read-Host "请选择 [1/2]"

if ($choice -eq "1") {
    # 查找 Chrome 路径
    $chromePaths = @(
        "C:\Program Files\Google\Chrome\Application\chrome.exe",
        "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    )
    
    $chromePath = $null
    foreach ($p in $chromePaths) {
        if (Test-Path $p) { $chromePath = $p; break }
    }
    
    if ($chromePath) {
        # 创建带 --app 参数的 Chrome 快捷方式
        $appShortcut = [Environment]::GetFolderPath("Desktop") + "\$AppName (独立窗口).lnk"
        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut($appShortcut)
        $Shortcut.TargetPath = $chromePath
        $Shortcut.Arguments = "--app=file:///$($HtmlPath.Replace('\', '/'))"
        if (Test-Path $IconPath) {
            $Shortcut.IconLocation = $IconPath
        }
        $Shortcut.WorkingDirectory = $ProjectDir
        $Shortcut.Save()
        
        Write-Host "  ✅ 已创建独立窗口快捷方式（Chrome 无边框模式）" -ForegroundColor Green
        Write-Host "  双击「$AppName (独立窗口)」即可像原生应用一样使用" -ForegroundColor White
    } else {
        Write-Host "  ⚠️ 未找到 Chrome，请手动安装 Chrome 浏览器" -ForegroundColor Yellow
    }
}
