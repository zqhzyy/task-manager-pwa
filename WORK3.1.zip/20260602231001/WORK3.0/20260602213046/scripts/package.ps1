$srcDir = 'c:/Users/张艺严/CodeBuddy/20260602231001/WORK3.0/20260602213046'
$releaseDir = Join-Path $srcDir 'release'

Write-Host '========================================' -ForegroundColor Cyan
Write-Host '   Task Manager v2.0 - Package Script' -ForegroundColor Cyan
Write-Host '========================================' -ForegroundColor Cyan
Write-Host ''

if (Test-Path $releaseDir) { Remove-Item $releaseDir -Recurse -Force }
New-Item -ItemType Directory -Path $releaseDir -Force | Out-Null

# 1. Standalone HTML
Write-Host '[1/3] Generating standalone HTML...' -ForegroundColor Cyan
$htmlDest = Join-Path $releaseDir 'task-manager.html'
Copy-Item (Join-Path $srcDir 'index.html') $htmlDest -Force
Write-Host '  OK task-manager.html' -ForegroundColor Green

# 2. Portable package
Write-Host '[2/3] Creating portable package...' -ForegroundColor Cyan
$packDir = Join-Path $releaseDir 'task-manager-v2'
New-Item -ItemType Directory -Path $packDir -Force | Out-Null

# Core files
Copy-Item (Join-Path $srcDir 'index.html') $packDir -Force
Copy-Item (Join-Path $srcDir 'manifest.json') $packDir -Force
Copy-Item (Join-Path $srcDir 'sw.js') $packDir -Force
Copy-Item (Join-Path $srcDir 'install-guide.html') $packDir -Force
Copy-Item (Join-Path $srcDir 'README.md') $packDir -Force -ErrorAction SilentlyContinue

# icons
$iconsDest = Join-Path $packDir 'icons'
New-Item -ItemType Directory -Path $iconsDest -Force | Out-Null
Copy-Item (Join-Path $srcDir 'icons\*') $iconsDest -Recurse -Force

# scripts
$scriptsDest = Join-Path $packDir 'scripts'
New-Item -ItemType Directory -Path $scriptsDest -Force | Out-Null
Get-ChildItem (Join-Path $srcDir 'scripts') -File | ForEach-Object {
    Copy-Item $_.FullName $scriptsDest -Force
}

# .github
$githubDest = Join-Path $packDir '.github'
Copy-Item (Join-Path $srcDir '.github') $githubDest -Recurse -Force

# ZIP
$zipPath = Join-Path $releaseDir 'task-manager-v2-portable.zip'
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }

Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($packDir, $zipPath)
Remove-Item $packDir -Recurse -Force
Write-Host '  OK task-manager-v2-portable.zip' -ForegroundColor Green

# 3. GitHub Pages deploy package
Write-Host '[3/3] Preparing GitHub Pages package...' -ForegroundColor Cyan
$ghDir = Join-Path $releaseDir 'github-pages'
New-Item -ItemType Directory -Path $ghDir -Force | Out-Null

Copy-Item (Join-Path $srcDir 'index.html') $ghDir -Force
Copy-Item (Join-Path $srcDir 'manifest.json') $ghDir -Force
Copy-Item (Join-Path $srcDir 'sw.js') $ghDir -Force
Copy-Item (Join-Path $srcDir 'install-guide.html') $ghDir -Force
Copy-Item (Join-Path $srcDir 'README.md') $ghDir -Force -ErrorAction SilentlyContinue

$ghIcons = Join-Path $ghDir 'icons'
New-Item -ItemType Directory -Path $ghIcons -Force | Out-Null
Copy-Item (Join-Path $srcDir 'icons\*') $ghIcons -Recurse -Force

$ghGithub = Join-Path $ghDir '.github'
Copy-Item (Join-Path $srcDir '.github') $ghGithub -Recurse -Force

Write-Host '  OK github-pages/ (push to GitHub for auto deploy)' -ForegroundColor Green

Write-Host ''
Write-Host '========================================' -ForegroundColor Cyan
Write-Host '   Package Complete!' -ForegroundColor Green
Write-Host '========================================' -ForegroundColor Cyan
Write-Host ''
Write-Host "Output: $releaseDir" -ForegroundColor White
Write-Host ''

Get-ChildItem $releaseDir -Recurse -File | ForEach-Object {
    $size = if ($_.Length -gt 1MB) { 
        "{0:N2} MB" -f ($_.Length/1MB) 
    } else { 
        "{0:N1} KB" -f ($_.Length/1KB) 
    }
    $relPath = $_.FullName.Replace($releaseDir, '').TrimStart('\')
    Write-Host "  $relPath ($size)" -ForegroundColor Yellow
}

Write-Host ''
Write-Host 'How to distribute:' -ForegroundColor White
Write-Host '  1. Send task-manager.html directly - open in browser' -ForegroundColor White
Write-Host '  2. Send task-manager-v2-portable.zip - extract and run' -ForegroundColor White
Write-Host '  3. Push github-pages/ to GitHub - auto deploy online' -ForegroundColor White
Write-Host ''

Start-Process $releaseDir
