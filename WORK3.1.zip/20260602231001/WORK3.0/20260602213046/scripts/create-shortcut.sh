#!/bin/bash
# 工作任务管理器 - macOS/Linux 桌面快捷方式创建工具
# 使用方法: bash create-shortcut.sh

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
APP_NAME="工作任务管理器"
HTML_PATH="$PROJECT_DIR/index.html"
ICON_PATH="$PROJECT_DIR/icons/icon-192x192.png"
DESKTOP_DIR="$HOME/Desktop"
APPS_DIR="$HOME/Applications"

echo ""
echo "========================================"
echo "   工作任务管理器 - 桌面快捷方式工具"
echo "========================================"
echo ""

# 检测操作系统
if [[ "$OSTYPE" == "darwin"* ]]; then
    echo "🍎 检测到 macOS 系统"
    IS_MACOS=true
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    echo "🐧 检测到 Linux 系统"
    IS_MACOS=false
else
    echo "⚠️  未知操作系统: $OSTYPE"
    IS_MACOS=false
fi

if [ ! -f "$HTML_PATH" ]; then
    echo "❌ 未找到 index.html，请确保在项目目录中运行此脚本"
    exit 1
fi

# macOS 快捷方式
if [ "$IS_MACOS" = true ]; then
    echo ""
    echo "[1/3] 创建 macOS 应用启动器..." 
    
    APP_DIR="$DESKTOP_DIR/$APP_NAME.app"
    mkdir -p "$APP_DIR/Contents/MacOS"
    mkdir -p "$APP_DIR/Contents/Resources"
    
    # 创建启动脚本
    cat > "$APP_DIR/Contents/MacOS/launcher" << 'LAUNCHER_EOF'
#!/bin/bash
APP_DIR="$(cd "$(dirname "$0")/../.." && pwd)"
HTML_PATH="$APP_DIR/../../index.html"
open "$HTML_PATH"
LAUNCHER_EOF
    chmod +x "$APP_DIR/Contents/MacOS/launcher"
    
    # 创建 Info.plist
    cat > "$APP_DIR/Contents/Info.plist" << 'PLIST_EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>launcher</string>
    <key>CFBundleIdentifier</key>
    <string>com.taskmanager.app</string>
    <key>CFBundleName</key>
    <string>工作任务管理器</string>
    <key>CFBundleDisplayName</key>
    <string>工作任务管理器</string>
    <key>CFBundleVersion</key>
    <string>2.0</string>
    <key>CFBundleShortVersionString</key>
    <string>2.0</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>LSMinimumSystemVersion</key>
    <string>10.10</string>
</dict>
</plist>
PLIST_EOF
    
    # 复制图标
    if [ -f "$ICON_PATH" ]; then
        cp "$ICON_PATH" "$APP_DIR/Contents/Resources/icon.icns" 2>/dev/null || true
    fi
    
    echo "  ✅ 桌面应用启动器已创建: $APP_NAME.app"
fi

# 通用方式：创建 .desktop 文件（Linux）
if [ "$IS_MACOS" = false ]; then
    echo ""
    echo "[1/3] 创建桌面快捷方式..."
    
    DESKTOP_FILE="$DESKTOP_DIR/$APP_NAME.desktop"
    
    cat > "$DESKTOP_FILE" << DESKTOP_EOF
[Desktop Entry]
Name=$APP_NAME
Comment=日常工作任务管理软件
Exec=xdg-open $HTML_PATH
Icon=$ICON_PATH
Terminal=false
Type=Application
Categories=Office;Utility;
StartupWMClass=task-manager
DESKTOP_EOF
    
    chmod +x "$DESKTOP_FILE"
    echo "  ✅ 桌面快捷方式已创建"
    
    # 添加到应用菜单
    if [ -d "$HOME/.local/share/applications" ]; then
        cp "$DESKTOP_FILE" "$HOME/.local/share/applications/$APP_NAME.desktop"
        echo "  ✅ 应用菜单快捷方式已创建"
    fi
fi

echo ""
echo "[2/3] 创建浏览器启动脚本..."

# 检测 Chrome
CHROME_PATH=""
if [ "$IS_MACOS" = true ]; then
    [ -f "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" ] && CHROME_PATH="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
else
    CHROME_PATH=$(which google-chrome 2>/dev/null || which google-chrome-stable 2>/dev/null || which chromium-browser 2>/dev/null || which chromium 2>/dev/null)
fi

if [ -n "$CHROME_PATH" ]; then
    # 创建独立窗口模式启动脚本
    STANDALONE_SCRIPT="$PROJECT_DIR/start-standalone.sh"
    cat > "$STANDALONE_SCRIPT" << STANDALONE_EOF
#!/bin/bash
# 工作任务管理器 - Chrome 独立窗口模式
"$CHROME_PATH" --app="file://$HTML_PATH" --window-size=1200,800 &
STANDALONE_EOF
    chmod +x "$STANDALONE_SCRIPT"
    
    # 创建独立窗口桌面快捷方式
    if [ "$IS_MACOS" = false ]; then
        STANDALONE_DESKTOP="$DESKTOP_DIR/$APP_NAME (独立窗口).desktop"
        cat > "$STANDALONE_DESKTOP" << STANDALONE_DESKTOP_EOF
[Desktop Entry]
Name=$APP_NAME (独立窗口)
Comment=以原生应用窗口模式打开
Exec=$STANDALONE_SCRIPT
Icon=$ICON_PATH
Terminal=false
Type=Application
Categories=Office;Utility;
STANDALONE_DESKTOP_EOF
        chmod +x "$STANDALONE_DESKTOP"
    fi
    
    echo "  ✅ Chrome 独立窗口模式已配置"
    echo "  运行: bash start-standalone.sh"
else
    echo "  ⚠️ 未找到 Chrome，跳过独立窗口配置"
fi

echo ""
echo "[3/3] 设置完成！"

# 打开桌面文件夹
if [ "$IS_MACOS" = true ]; then
    open "$DESKTOP_DIR" 2>/dev/null || true
else
    xdg-open "$DESKTOP_DIR" 2>/dev/null || true
fi

echo ""
echo "========================================"
echo "  🎉 快捷方式创建完成！" 
echo "========================================"
echo ""
echo "📌 现在可以：" 
echo "  1. 在桌面双击「$APP_NAME」打开应用"
echo "  2. 在应用菜单搜索「$APP_NAME」"
if [ -n "$CHROME_PATH" ]; then
    echo "  3. 双击「$APP_NAME (独立窗口)」以原生应用模式运行"
fi
echo ""
echo "💡 提示：" 
echo "  - 推荐用 Chrome 浏览器打开，体验最佳"
echo "  - 打开后可点击左侧「💻 安装到电脑」获得完整 PWA 体验"
echo ""
