<#
.SYNOPSIS
工作任务管理器 - 跨平台一键部署脚本
支持：GitHub Pages / 本地 HTTPS 服务器 / 打包分发
#>

param(
    [ValidateSet('github','local','zip','all')]
    [string]$Mode = 'all',
    [int]$Port = 8443
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectDir = Split-Path -Parent $ScriptDir
Set-Location $ProjectDir

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   工作任务管理器 - 跨平台部署工具 v2.0" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 创建输出目录
$releaseDir = Join-Path $ProjectDir "release"
if (Test-Path $releaseDir) { Remove-Item $releaseDir -Recurse -Force }
New-Item -ItemType Directory -Path $releaseDir -Force | Out-Null

# ====== 功能1：生成便携版 ZIP ======
function Create-PortableZip {
    Write-Host "[1/4] 创建便携版 ZIP..." -ForegroundColor Cyan
    
    $packDir = Join-Path $releaseDir "工作任务管理器_v2.0"
    New-Item -ItemType Directory -Path $packDir -Force | Out-Null
    
    # 复制核心文件
    Copy-Item (Join-Path $ProjectDir "index.html") $packDir -Force
    Copy-Item (Join-Path $ProjectDir "manifest.json") $packDir -Force
    Copy-Item (Join-Path $ProjectDir "sw.js") $packDir -Force
    
    # 复制 icons
    $iconsSrc = Join-Path $ProjectDir "icons"
    if (Test-Path $iconsSrc) {
        $iconsDest = Join-Path $packDir "icons"
        New-Item -ItemType Directory -Path $iconsDest -Force | Out-Null
        Copy-Item (Join-Path $iconsSrc "*") $iconsDest -Recurse -Force
    }
    
    # 生成使用说明
    @"
工作任务管理器 v2.0 - 跨平台版
================================

📋 功能特性：
  - 三类任务：关注跟踪事项 / 临时任务 / 计划工作
  - 优先级管理：高🔴 / 中🟡 / 低🟢
  - 五级进度：启动 → 1/4 → 1/2 → 3/4 → 全部完成
  - 到期提醒：到期前 1h/5h/1天/3天/5天 + 逾期提醒
  - 文件导入：支持 TXT / MD / CSV
  - PWA 安装：可安装到电脑和手机桌面

🚀 安装到桌面：
  电脑（Chrome/Edge）：
    1. 双击 index.html 用浏览器打开
    2. 点击左侧「💻 安装到电脑」
    3. 或点击浏览器地址栏右侧的安装图标
    
  iPhone/iPad（Safari）：
    1. 用 Safari 打开此页面
    2. 点击底部分享按钮（方框+箭头）
    3. 选择「添加到主屏幕」
    
  安卓手机（Chrome）：
    1. 用 Chrome 打开此页面
    2. 点击「📱 添加到手机桌面」
    3. 或等待底部弹出安装提示

📁 文件说明：
  index.html     - 主程序（可离线使用）
  manifest.json  - PWA 配置文件
  sw.js         - Service Worker（离线缓存+推送通知）
  icons/        - 应用图标

💡 提示：
  - 推荐使用 Chrome / Edge / Safari 浏览器
  - 数据存储在浏览器本地，请勿清理浏览器数据
  - 使用「导出数据」功能可备份任务数据
"@ | Out-File -FilePath (Join-Path $packDir "使用说明.txt") -Encoding UTF8
    
    # 打包 ZIP
    $zipPath = Join-Path $releaseDir "工作任务管理器_v2.0_跨平台便携包.zip"
    if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
    
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::CreateFromDirectory($packDir, $zipPath)
    
    Remove-Item $packDir -Recurse -Force
    Write-Host "  ✅ 工作任务管理器_v2.0_跨平台便携包.zip" -ForegroundColor Green
}

# ====== 功能2：生成独立 HTML 文件 ======
function Create-StandaloneHTML {
    Write-Host "[2/4] 生成独立 HTML 文件..." -ForegroundColor Cyan
    
    $htmlPath = Join-Path $releaseDir "工作任务管理器.html"
    Copy-Item (Join-Path $ProjectDir "index.html") $htmlPath -Force
    
    Write-Host "  ✅ 工作任务管理器.html (双击浏览器打开即可使用)" -ForegroundColor Green
}

# ====== 功能3：生成 GitHub Pages 部署包 ======
function Create-GitHubPages {
    Write-Host "[3/4] 准备 GitHub Pages 部署..." -ForegroundColor Cyan
    
    $ghDir = Join-Path $releaseDir "github-pages"
    New-Item -ItemType Directory -Path $ghDir -Force | Out-Null
    
    # 复制所有必要文件
    Copy-Item (Join-Path $ProjectDir "index.html") $ghDir -Force
    Copy-Item (Join-Path $ProjectDir "manifest.json") $ghDir -Force
    Copy-Item (Join-Path $ProjectDir "sw.js") $ghDir -Force
    Copy-Item (Join-Path $ProjectDir "README.md") $ghDir -Force -ErrorAction SilentlyContinue
    Copy-Item (Join-Path $ProjectDir ".gitignore") $ghDir -Force -ErrorAction SilentlyContinue
    
    # 复制 icons
    $iconsSrc = Join-Path $ProjectDir "icons"
    if (Test-Path $iconsSrc) {
        $iconsDest = Join-Path $ghDir "icons"
        New-Item -ItemType Directory -Path $iconsDest -Force | Out-Null
        Copy-Item (Join-Path $iconsSrc "*") $iconsDest -Recurse -Force
    }
    
    # 复制 .github 工作流
    $ghSrc = Join-Path $ProjectDir ".github"
    if (Test-Path $ghSrc) {
        Copy-Item $ghSrc $ghDir -Recurse -Force
    }
    
    Write-Host "  ✅ GitHub Pages 部署包已准备" -ForegroundColor Green
    Write-Host "  将 $ghDir 目录内容推送到 GitHub 仓库即可自动部署" -ForegroundColor White
}

# ====== 功能4：启动本地 HTTPS 测试服务器 ======
function Start-LocalServer {
    Write-Host "[4/4] 启动本地 HTTPS 服务器..." -ForegroundColor Cyan
    
    # 检查是否有证书
    $certDir = Join-Path $ScriptDir "certs"
    $certFile = Join-Path $certDir "server.crt"
    $keyFile = Join-Path $certDir "server.key"
    
    if (-not (Test-Path $certFile) -or -not (Test-Path $keyFile)) {
        Write-Host "  ⚠️ 未找到 SSL 证书，正在生成自签名证书..." -ForegroundColor Yellow
        
        # 检查 OpenSSL
        $openssl = Get-Command openssl -ErrorAction SilentlyContinue
        if (-not $openssl) {
            Write-Host "  ❌ 未找到 OpenSSL，无法生成证书" -ForegroundColor Red
            Write-Host "  请安装 OpenSSL: https://slproweb.com/products/Win32OpenSSL.html" -ForegroundColor Yellow
            Write-Host "  或手动生成证书后放在 $certDir 目录" -ForegroundColor Yellow
            return
        }
        
        New-Item -ItemType Directory -Path $certDir -Force | Out-Null
        & openssl req -x509 -newkey rsa:2048 -keyout $keyFile -out $certFile -days 365 -nodes -subj "/CN=localhost/O=TaskManager/C=CN" 2>$null
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "  ✅ SSL 证书已生成" -ForegroundColor Green
        } else {
            Write-Host "  ❌ 证书生成失败" -ForegroundColor Red
            return
        }
    }
    
    # 尝试用 Python 启动
    $python = Get-Command python -ErrorAction SilentlyContinue
    if (-not $python) { $python = Get-Command python3 -ErrorAction SilentlyContinue }
    
    if ($python) {
        Write-Host "  ✅ 使用 Python 启动 HTTPS 服务器..." -ForegroundColor Green
        Write-Host ""
        Write-Host "  🌐 电脑访问: https://localhost:$Port" -ForegroundColor Yellow
        Write-Host "  📱 手机访问: https://你的电脑IP:$Port" -ForegroundColor Yellow
        Write-Host "  (确保手机和电脑在同一网络，并信任自签名证书)" -ForegroundColor White
        Write-Host ""
        
        # 获取本机 IP
        $ip = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.InterfaceAlias -notmatch "Loopback" -and $_.IPAddress -notlike "169.*" } | Select-Object -First 1).IPAddress
        if ($ip) {
            Write-Host "  📍 本机 IP: $ip" -ForegroundColor Cyan
            Write-Host "  📱 手机访问: https://${ip}:$Port" -ForegroundColor Cyan
        }
        Write-Host ""
        
        # 启动服务器
        $serverScript = Join-Path $ScriptDir "pwa-server.py"
        if (Test-Path $serverScript) {
            Set-Location $ProjectDir
            & python $serverScript --port $Port
        } else {
            Write-Host "  ❌ 未找到服务器脚本" -ForegroundColor Red
        }
    } else {
        Write-Host "  ❌ 未找到 Python" -ForegroundColor Red
        Write-Host "  请安装 Python: https://www.python.org/downloads/" -ForegroundColor Yellow
    }
}

# ====== 主逻辑 ======
switch ($Mode) {
    'all' {
        Create-PortableZip
        Create-StandaloneHTML
        Create-GitHubPages
        Write-Host ""
        Write-Host "========================================" -ForegroundColor Cyan
        Write-Host "  打包完成！" -ForegroundColor Green
        Write-Host "========================================" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "📦 输出文件位于: $releaseDir" -ForegroundColor White
        Write-Host ""
        Get-ChildItem $releaseDir -Recurse -File | ForEach-Object {
            $size = if ($_.Length -gt 1MB) { "{0:N2} MB" -f ($_.Length/1MB) } else { "{0:N1} KB" -f ($_.Length/1KB) }
            $relPath = $_.FullName.Replace($releaseDir, '').TrimStart('\')
            Write-Host "  📄 $relPath ($size)" -ForegroundColor Yellow
        }
        Write-Host ""
        Write-Host "🚀 下一步：" -ForegroundColor White
        Write-Host "  1. 将 ZIP 发给他人 → 解压后双击 index.html 即可使用" -ForegroundColor White
        Write-Host "  2. 将 HTML 直接发给他人 → 双击浏览器打开即可使用" -ForegroundColor White
        Write-Host "  3. 将 github-pages 目录推送到 GitHub → 自动部署为在线版" -ForegroundColor White
        Write-Host "  4. 运行 .\deploy.ps1 -Mode local → 启动本地 HTTPS 测试服务器" -ForegroundColor White
        Write-Host ""
    }
    'zip' {
        Create-PortableZip
        Create-StandaloneHTML
    }
    'github' {
        Create-GitHubPages
    }
    'local' {
        Start-LocalServer
    }
}

# 打开输出目录
if ($Mode -ne 'local') {
    Start-Process $releaseDir
}
