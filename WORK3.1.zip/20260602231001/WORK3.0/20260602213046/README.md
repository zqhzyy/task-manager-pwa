# 📋 工作任务管理器 v2.0

一个支持跨平台 PWA 安装的任务管理应用，可安装到 **Windows / macOS / Linux 电脑桌面**和 **iPhone / Android 手机桌面**。

## ✨ 功能

- 📊 **仪表盘** — 任务统计概览，完成率、优先级分布一目了然
- 👁️ **关注跟踪** — 长期跟踪的重要事项，支持责任部门/责任人
- ⚡ **临时任务** — 突发需要处理的临时工作
- 📅 **计划工作** — 有明确计划的周期性工作
- 🔔 **到期提醒** — 到期前 1 小时 / 5 小时 / 1 天 / 3 天 / 5 天 + 逾期提醒
- 📥 **文件导入** — 支持 TXT / MD / CSV 批量导入
- 💻📱 **跨平台安装** — 一键安装到电脑桌面和手机主屏幕，离线也能用

---

## 🚀 安装到桌面

### 💻 电脑端（Windows / macOS / Linux）

**方法一：浏览器 PWA 安装（推荐）**

1. 用 **Chrome** 或 **Edge** 浏览器打开应用页面
2. 点击左侧菜单中的 **「💻 安装到电脑」** 按钮
3. 或点击浏览器地址栏右侧的 📥 安装图标
4. 应用会自动添加到桌面，像原生软件一样使用

**方法二：创建桌面快捷方式**

```bash
# Windows
powershell -File scripts/create-shortcut.ps1

# macOS / Linux
bash scripts/create-shortcut.sh
```

**方法三：Chrome 独立窗口模式（无边框，更像原生应用）**

```bash
# Windows
powershell -File scripts/create-shortcut.ps1
# 选择「1」使用 Chrome 独立窗口

# macOS / Linux
bash scripts/create-shortcut.sh
# 自动生成 start-standalone.sh 脚本
```

### 📱 手机端

**iPhone / iPad（Safari）**

1. 用 **Safari 浏览器**打开应用页面
2. 点击底部 **分享按钮**（方框+向上箭头图标）
3. 在弹出菜单中滑动找到 **「添加到主屏幕」**
4. 点击右上角 **「添加」**，图标会出现在主屏幕

**安卓手机（Chrome）**

1. 用 **Chrome 浏览器**打开应用页面
2. 点击左侧菜单中的 **「📱 安装到手机」** 按钮
3. 或等待底部弹出安装横幅，点击 **「安装」**
4. 应用会添加到手机主屏幕

> 💡 **提示**：打开 `install-guide.html` 页面可查看图文安装引导

---

## 📦 部署方式

### 方式一：直接使用（零部署）

双击 `index.html` 用浏览器打开即可使用。

### 方式二：部署到 GitHub Pages（推荐，支持 PWA 全功能）

1. 将项目推送到 GitHub 仓库
2. 进入 Settings → Pages → Source 选择 `GitHub Actions`
3. 推送代码后自动部署
4. 访问 `https://你的用户名.github.io/仓库名/`

### 方式三：部署到任意 HTTPS 服务器

将整个项目文件夹上传到 HTTPS 静态服务器即可。

> ⚠️ **注意**：PWA 安装功能需要 HTTPS 才能正常工作

### 方式四：本地 HTTPS 测试服务器

```bash
# Windows
powershell -File scripts/deploy.ps1 -Mode local

# macOS / Linux
python3 scripts/pwa-server.py --port 8443
```

---

## 🛠 一键打包分发

```bash
# 生成便携包、独立HTML和GitHub Pages部署包
powershell -File scripts/deploy.ps1

# 仅生成便携ZIP
powershell -File scripts/deploy.ps1 -Mode zip

# 仅准备GitHub Pages
powershell -File scripts/deploy.ps1 -Mode github
```

---

## 📁 项目结构

```
├── index.html              # 主应用（单文件，可离线使用）
├── manifest.json           # PWA 配置文件
├── sw.js                   # Service Worker（离线缓存+推送通知）
├── install-guide.html      # 跨平台安装引导页
├── icons/                  # 应用图标（多尺寸）
├── scripts/
│   ├── deploy.ps1          # 一键部署/打包脚本
│   ├── create-shortcut.ps1 # Windows 桌面快捷方式生成
│   ├── create-shortcut.sh  # macOS/Linux 桌面快捷方式生成
│   ├── pwa-server.py       # 本地 HTTPS 测试服务器
│   ├── start-server.bat    # Windows 快速启动服务器
│   ├── generate-png-icons.html # 图标生成工具
│   └── certs/              # SSL 证书目录
└── .github/workflows/      # GitHub Actions 自动部署
```

## 🛠 技术栈

- 纯前端 PWA（无需后端）
- Service Worker 离线缓存（缓存优先 + 网络回退策略）
- localStorage 数据存储
- GitHub Pages 自动部署
- 跨平台自适应安装引导

---

## 🔒 隐私说明

- 所有数据存储在**浏览器本地 localStorage** 中
- **不收集、不上传**任何用户数据
- 无需注册账号，无需联网即可使用
- 建议定期使用「导出数据」功能备份任务数据
