// Service Worker - 工作任务管理器 v5 - 跨平台优化版
const CACHE_NAME = 'task-manager-v5-' + new Date().toISOString().slice(0, 10);
const RUNTIME_CACHE = 'task-manager-runtime-v5';

// 预缓存的核心资源（确保离线可用）
const PRECACHE_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-72x72.png',
  './icons/icon-96x96.png',
  './icons/icon-128x128.png',
  './icons/icon-144x144.png',
  './icons/icon-152x152.png',
  './icons/icon-192x192.png',
  './icons/icon-384x384.png',
  './icons/icon-512x512.png',
  './icons/icon-72x72.svg',
  './icons/icon-512x512.svg'
];

// ========== 安装事件 ==========
self.addEventListener('install', (event) => {
  console.log('[SW] Installing v5...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[SW] Precaching ' + PRECACHE_ASSETS.length + ' assets...');
        return Promise.allSettled(
          PRECACHE_ASSETS.map(url =>
            cache.add(url).catch(err => {
              console.warn('[SW] Failed to cache:', url, err.message);
            })
          )
        );
      })
      .then(() => {
        console.log('[SW] Install complete, activating immediately');
        return self.skipWaiting();
      })
  );
});

// ========== 激活事件 ==========
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating v5...');
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys
          .filter(k => k !== CACHE_NAME && k !== RUNTIME_CACHE)
          .map(k => {
            console.log('[SW] Deleting old cache:', k);
            return caches.delete(k);
          })
      );
    }).then(() => {
      console.log('[SW] Activated, claiming clients...');
      return self.clients.claim();
    })
  );
});

// ========== 请求拦截策略 ==========
self.addEventListener('fetch', (event) => {
  // 跳过非 GET 请求
  if (event.request.method !== 'GET') return;
  
  // 跳过 chrome-extension 等非 http(s) 请求
  const url = new URL(event.request.url);
  if (!url.protocol.startsWith('http')) return;

  // 策略 1: 核心静态资源 - Cache First（缓存优先）
  if (isStaticAsset(url)) {
    event.respondWith(cacheFirst(event.request));
    return;
  }

  // 策略 2: 其他请求 - Network First（网络优先，失败后回退缓存）
  event.respondWith(networkFirst(event.request));
});

// 缓存优先策略（用于静态资源）
async function cacheFirst(request) {
  const cached = await caches.match(request);
  if (cached) {
    // 后台静默更新缓存
    fetch(request).then(response => {
      if (response && response.status === 200) {
        caches.open(CACHE_NAME).then(cache => cache.put(request, response.clone()));
      }
    }).catch(() => {});
    return cached;
  }
  
  try {
    const response = await fetch(request);
    if (response && response.status === 200) {
      const cache = await caches.open(RUNTIME_CACHE);
      cache.put(request, response.clone());
    }
    return response;
  } catch (err) {
    // 返回离线页面（如果请求的是 HTML）
    if (request.headers.get('accept') && request.headers.get('accept').includes('text/html')) {
      const offlineCache = await caches.match('./index.html');
      return offlineCache || new Response('离线模式 - 请连接网络后重试', {
        status: 503,
        statusText: 'Service Unavailable',
        headers: { 'Content-Type': 'text/plain; charset=utf-8' }
      });
    }
    return new Response('', { status: 408, statusText: 'Request Timeout' });
  }
}

// 网络优先策略（用于动态内容）
async function networkFirst(request) {
  try {
    const response = await fetch(request);
    if (response && response.status === 200) {
      const cache = await caches.open(RUNTIME_CACHE);
      cache.put(request, response.clone());
    }
    return response;
  } catch (err) {
    const cached = await caches.match(request);
    if (cached) return cached;
    
    // 请求 HTML 时回退到离线页
    if (request.headers.get('accept') && request.headers.get('accept').includes('text/html')) {
      const offlineCache = await caches.match('./index.html');
      return offlineCache || new Response('离线模式', { status: 503 });
    }
    throw err;
  }
}

// 判断是否为静态资源
function isStaticAsset(url) {
  const staticExtensions = ['.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.css', '.js', '.woff', '.woff2', '.ttf', '.json', '.webp', '.webmanifest'];
  const staticPaths = ['/icons/', '/assets/', '/static/'];
  
  return staticExtensions.some(ext => url.pathname.toLowerCase().endsWith(ext)) ||
         staticPaths.some(p => url.pathname.includes(p));
}

// ========== 推送通知（跨平台增强） ==========
self.addEventListener('push', (event) => {
  let data = {};
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data = { body: event.data.text(), title: '工作任务管理器' };
    }
  }

  const options = {
    body: data.body || '您有任务需要处理',
    icon: './icons/icon-192x192.png',
    badge: './icons/icon-72x72.png',
    tag: data.tag || 'task-reminder',
    renotify: true,
    requireInteraction: data.requireInteraction !== false,
    vibrate: data.vibrate || [200, 100, 200, 100, 200],
    actions: data.actions || [
      { action: 'view', title: '查看详情' },
      { action: 'dismiss', title: '忽略' }
    ],
    data: {
      url: data.url || './',
      timestamp: Date.now(),
      ...data.extraData
    },
    silent: data.silent || false,
    timestamp: Date.now()
  };

  event.waitUntil(
    self.registration.showNotification(
      data.title || '📋 工作任务管理器',
      options
    )
  );
});

// 通知点击处理
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const action = event.action;
  const targetUrl = event.notification.data && event.notification.data.url 
    ? event.notification.data.url 
    : './';

  if (action === 'dismiss') {
    // 忽略操作，不做任何事
    return;
  }

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // 查找已打开的窗口
      for (const client of clientList) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          // 如果目标 URL 不同，先导航
          if (targetUrl !== './' && !client.url.includes(targetUrl)) {
            return client.navigate(targetUrl).then(() => client.focus());
          }
          return client.focus();
        }
      }
      // 没有已打开的窗口，创建新窗口
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});

// ========== 后台同步（支持离线操作队列） ==========
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-tasks') {
    event.waitUntil(syncTasks());
  }
});

async function syncTasks() {
  try {
    // 通知所有客户端数据已同步
    const clients = await self.clients.matchAll({ type: 'window' });
    clients.forEach(client => {
      client.postMessage({ type: 'SYNC_COMPLETE', timestamp: Date.now() });
    });
    console.log('[SW] Background sync completed');
  } catch (err) {
    console.error('[SW] Background sync failed:', err);
  }
}

// ========== 消息通信 ==========
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'UPDATE_CACHE') {
    event.waitUntil(
      caches.open(CACHE_NAME).then(cache => {
        return cache.addAll(PRECACHE_ASSETS).catch(err => {
          console.warn('[SW] Cache update partial:', err);
        });
      })
    );
  }
  
  if (event.data && event.data.type === 'GET_VERSION') {
    event.ports[0].postMessage({ version: CACHE_NAME });
  }
});
